from time import time
import pyautogui
import time
import time
import pyttsx3
import speech_recognition as sr
import datetime
import platform
import easygui
import seaborn as sns


if platform.system() == "Windows":
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)
    userSaid = "hello world"
else:
    engine = pyttsx3.init()
    engine.setProperty('voice', 'english-us')
    engine.setProperty('rate', 160)
    userSaid = "hello world"

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning! MORNING SPIRIT!")

    elif hour >= 12 and hour < 18:
        speak("Good Afternoon! FOCUS and SPIRIT")

    else:
        speak("Good Night! Don't forget to rest")

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def takecommand(wtr=0):
    r = sr.Recognizer()
    r.pause_threshold = 1
    r.operation_timeout = 5
    with sr.Microphone() as source:
        speak("Anda yang bisa saya bantu, Galih!")
        print("Listening...")
        audio = r.listen(source, phrase_time_limit=5)

        try:
            print("Recognizing...\n")
            heard = r.recognize_google(audio)
            print(f"You Said: \"{heard}\"")
            return heard.lower()
        except sr.UnknownValueError:

            speak("Mohon maaf saya tidak bisa memahami perkataan anda!")
            print(
                "You said something that is beyond my understanding or maybe you didn't say anything.\n")
            engine.runAndWait()
            return 0

speak("Opening windows run")
pyautogui.hotkey('winleft', 'r')
pyautogui.typewrite("code")
speak("typing code for open Visual Studio Code")
pyautogui.press("enter")
time.sleep(10)
speak("Please wait 10 seconds to create the file")
pyautogui.hotkey('ctrl','alt', 'win', 'n')
pyautogui.hotkey('down')
pyautogui.press("enter")

def introduction():
    print("Getting started without wasting your precious time...")
    speak("Hello, introduce me Galbot, may I meet you")
    msg = "Silakan masukan nama anda"
    title = "Perkenalan Galbot"
    fieldNames = ["Nama"]
    fieldValues = [] 
    fieldValues = easygui.multenterbox(msg,title, fieldNames)
    print(fieldValues)

    while 1:
        if fieldValues == None: break
        errmsg = ""
        for i in range(len(fieldNames)):
            if fieldValues[i].strip() == "":
                errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
        if errmsg == "": break # no problems found
        fieldValues = easygui.multenterbox(errmsg, title, fieldNames, fieldValues)
    speak(f"Hallo {fieldValues[0]}")

introduction()
speak("Galbot writing a program...")
engine.runAndWait()
pyautogui.typewrite(f'''from distutils import extension
from fileinput import filename
import os
import shutil

path = input("Enter Path: ")
files = os.listdir(path)

for file in files:
    filename, extension = os.path.splitext(file)\nextension = extension[1:]

if os.path.exists(path+ '/' + extension):
    shutil.move(path+'/'+file, path+'/'+extension+'/'+file)'''
)
pyautogui.press("enter")
pyautogui.press("backspace")
pyautogui.typewrite('''
else:
    os.makedirs(path+'/'+extension)\nshutil.move(path+'/'+file, path+'/'+extension+'/'+file)'''
)
speak("Galbot finished writing the program")