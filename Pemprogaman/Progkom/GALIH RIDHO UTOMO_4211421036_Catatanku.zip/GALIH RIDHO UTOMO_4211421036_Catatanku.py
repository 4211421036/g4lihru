#Nama   : GALIH RIDHO UTOMO
#NIM    : 4211421036
#Prodi  : Fisika Murni
#PAMK   : Catatanku

import tkinter as tk
from tkinter import Label, ttk, font, colorchooser, messagebox, filedialog
from tkinter.messagebox import *
import webview
import os
import pyttsx3
import platform
from datetime import datetime
import random
import pyautogui

os.system("python -m pip install thinter Arg")
os.system("python -m pip install webview Arg")
os.system("python -m pip install PyAutoGUI Arg")
os.system("python -m pip install pyttsx3 Arg")


CatatanKu = tk.Tk()
now = datetime.now() 
FormatWaktu = now.strftime("%d/%m/%Y")
print("\ndate and time =", FormatWaktu)	
CatatanKu.title(f"Untitled - Catatan - {FormatWaktu}")
CatatanKu.geometry("800x600+230+40")
CatatanKu.iconbitmap('icons/mycon.ico')
CatatanKu.update()

MainMenu = tk.Menu()
file = tk.Menu(MainMenu,tearoff=False)
NewIcon = tk.PhotoImage(file="icons/new.png")
OpenIcon = tk.PhotoImage(file="icons/open.png")
SaveIcon = tk.PhotoImage(file="icons/save.png")
SaveAsIcon = tk.PhotoImage(file="icons/save.png")
PrintIcon = tk.PhotoImage(file="icons/print.png")
ExitIcon = tk.PhotoImage(file="icons/exit.png")

ai = tk.Menu(MainMenu,tearoff=False)
VAIIIcon = tk.PhotoImage(file="icons/vaii.png")
EMAIIcon = tk.PhotoImage(file="icons/emai.png")
GalbotIcon = tk.PhotoImage(file="icons/galbot1.png")

kuliah = tk.Menu(MainMenu,tearoff=False)
RekamIcon = tk.PhotoImage(file="icons/record.png")
RunIcon = tk.PhotoImage(file="icons/run.png")
SpwrIcon = tk.PhotoImage(file="icons/spwr.png")
ClassIcon = tk.PhotoImage(file="icons/class.png")
ElenaIcon = tk.PhotoImage(file="icons/elena.png")
DriveIcon = tk.PhotoImage(file="icons/drive.png")
CloudIco = tk.PhotoImage(file="icons/myclod.png")

tentang = tk.Menu(MainMenu,tearoff=False)
AboutIcon = tk.PhotoImage(file="icons/about.png")
help_icon = tk.PhotoImage(file="icons/about.png")

edit = tk.Menu(MainMenu,tearoff=False)
CopyIcon = tk.PhotoImage(file="icons/copy.png")
PasteIcon = tk.PhotoImage(file="icons/paste.png")
CutIcon = tk.PhotoImage(file="icons/cut.png")
FindIcon = tk.PhotoImage(file="icons/find.png")

view = tk.Menu(MainMenu,tearoff=False)
ToolBarIcon = tk.PhotoImage(file="icons/ToolBar.png")
StatusBarIcon = tk.PhotoImage(file="icons/StatusBar.png")

color = tk.Menu(MainMenu,tearoff=False)
RandomIcon = tk.PhotoImage(file="icons/tema.png")
TerangIcon = tk.PhotoImage(file="icons/light_default.png")
ClamIcon = tk.PhotoImage(file="icons/light_default.png")
TemaTerang = tk.PhotoImage(file="icons/light_default.png")
TerangPlusIcon = tk.PhotoImage(file="icons/light_plus.png")
DarkIcon = tk.PhotoImage(file="icons/dark.png")

ThemeChoise = tk.StringVar()
ColorIcon = (TerangIcon,TerangPlusIcon,DarkIcon)
ColorList={
    "White":('#000000','#ffffff'),  #here there is text color and backgrund color
    "Grey":('#b1b2b3', '#3d424d'),
    "Dark":('#e2f4ff','#171a1d')
}

MainMenu.add_cascade(label="Files",menu=file)
MainMenu.add_cascade(label="Edit",menu=edit)
MainMenu.add_cascade(label="View",menu=view)
MainMenu.add_cascade(label="Theme",menu=color)
MainMenu.add_cascade(label="AI",menu=ai)
MainMenu.add_cascade(label="Kuliah",menu=kuliah)
MainMenu.add_cascade(label="About",menu=tentang)

ToolBar = ttk.Label(CatatanKu)
ToolBar.pack(side=tk.TOP, fill=tk.X)

FontTup = tk.font.families()
FontFam = tk.StringVar()
FontCom = ttk.Combobox(ToolBar,width=25,state="readonly",textvariable=FontFam)
FontCom['values'] = FontTup
FontCom.grid(row=0,column=0,padx=4)
FontCom.current(FontTup.index('Arial'))

Ukuran = tk.IntVar()
UkuranCom = ttk.Combobox(ToolBar,width=15,textvariable=Ukuran,state="readonly")
UkuranCom['values'] = tuple(range(5,50,3))
UkuranCom.grid(row=0,column=1,padx=4)
UkuranCom.current(3)

BoldIcon = tk.PhotoImage(file='icons/bold.png')
ItalicIcon = tk.PhotoImage(file='icons/italic.png')
UnderlineIcon = tk.PhotoImage(file='icons/underline.png')
FontColorIcon = tk.PhotoImage(file='icons/font_color.png')
AlignLeftIcon = tk.PhotoImage(file='icons/align_left.png')
AlignRightIcon = tk.PhotoImage(file='icons/align_right.png')
align_center_icon = tk.PhotoImage(file='icons/align_center.png')

BoldButton = ttk.Button(ToolBar,image=BoldIcon)
BoldButton.grid(row=0,column=2,padx=1)

ItalicButton = ttk.Button(ToolBar,image=ItalicIcon)
ItalicButton.grid(row=0,column=3,padx=1)

UnderlineButton = ttk.Button(ToolBar,image=UnderlineIcon)
UnderlineButton.grid(row=0,column=4,padx=1)

FontColorBut = ttk.Button(ToolBar,image=FontColorIcon)
FontColorBut.grid(row=0,column=5,padx=1)

AlignLeftBut = ttk.Button(ToolBar,image=AlignLeftIcon)
AlignLeftBut.grid(row=0,column=6,padx=1)

AlignCenterBut = ttk.Button(ToolBar,image=align_center_icon)
AlignCenterBut.grid(row=0,column=7,padx=1)

AlignRightBut = ttk.Button(ToolBar,image=AlignRightIcon)
AlignRightBut.grid(row=0,column=8,padx=1)

TextEditor = tk.Text(CatatanKu)
TextEditor.config(wrap='word',relief=tk.FLAT)
TextEditor.focus_set()

ScrollBar = tk.Scrollbar(CatatanKu)
ScrollBar.pack(side=tk.RIGHT,fill=tk.Y)
TextEditor.pack(fill=tk.BOTH,expand=True)
ScrollBar.config(command=TextEditor.yview)
TextEditor.config(yscrollcommand=ScrollBar.set)

DefaultFontFam = "Arial"
DefaultFontSize = 12

def NgubahFont(CatatanKu):
    global DefaultFontFam
    DefaultFontFam = FontFam.get()
    TextEditor.configure(font=(DefaultFontFam,DefaultFontSize))

def NgubahUkuran(CatatanKu):
    global DefaultFontSize
    DefaultFontSize=Ukuran.get()
    TextEditor.configure(font=(DefaultFontFam,DefaultFontSize))

FontCom.bind('<<ComboboxSelected>>',NgubahFont)
UkuranCom.bind('<<ComboboxSelected>>',NgubahUkuran)

def NgubahBold(event=None):
    text_property = tk.font.Font(font=TextEditor['font'])
    if text_property.actual()['weight'] == 'normal':
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'bold'))
    if text_property.actual()['weight'] == 'bold':
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'normal'))
BoldButton.configure(command=NgubahBold)

def NgubahItalic(event=None):
    italic = tk.font.Font(font=TextEditor['font'])
    if italic.actual()['slant']=='roman':
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'italic'))
    if italic.actual()['slant']=='italic':
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'roman'))
ItalicButton.configure(command=NgubahItalic)

def NguUnLin(event=None):
    underline = tk.font.Font(font=TextEditor['font'])
    if underline.actual()['underline'] == 0:
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'underline'))
    if underline.actual()['underline'] == 1:
        TextEditor.configure(font=(DefaultFontFam, DefaultFontSize, 'normal'))
UnderlineButton.configure(command=NguUnLin)

def NgubahColor():
    color = tk.colorchooser.askcolor()
    TextEditor.configure(fg=color[1])
FontColorBut.configure(command=NgubahColor)

def left(event=None):
    text_content = TextEditor.get(1.0,'end')
    TextEditor.tag_config('left',justify=tk.LEFT)
    TextEditor.delete(1.0,tk.END)
    TextEditor.insert(tk.INSERT,text_content,'left')
AlignLeftBut.configure(command=left)

def center(event=None):
    text_content = TextEditor.get(1.0,'end')
    TextEditor.tag_config('center',justify=tk.CENTER)
    TextEditor.delete(1.0,tk.END)
    TextEditor.insert(tk.INSERT,text_content,'center')
AlignCenterBut.configure(command=center)

def right(event=None):
    text_content = TextEditor.get(1.0,'end')
    TextEditor.tag_config('right', justify=tk.RIGHT)
    TextEditor.delete(1.0, tk.END)
    TextEditor.insert(tk.INSERT,text_content, 'right')
AlignRightBut.configure(command=right)

TextEditor.configure(font=("Arial", 12))

StatusBar = ttk.Label(CatatanKu, text="Status Bar")
StatusBar.pack(side=tk.BOTTOM)

plat = platform.system()
ou = os.name

TextPeru = False
def changed(event=None):
    global TextPeru
    if TextEditor.edit_modified():
        TextPeru = True
        words = len(TextEditor.get(1.0,'end-1c').split())
        characters = len(TextEditor.get(1.0,'end-1c'))
        StatusBar.config(compound=tk.LEFT, text=f"Characters:{characters}  Words : {words} \t \t | UTF-8 \t \t | {plat} {ou}")
    TextEditor.edit_modified(False)

TextEditor.bind('<<Modified>>',changed)

url = '' 

def FileBaru(event=None):
    global url
    url = ''
    TextEditor.delete(1.0,tk.END)

file.add_command(label="New",image=NewIcon,compound=tk.LEFT,accelerator="Ctrl+N",command=FileBaru)

def rekam(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.geometry("800x600")
    webview.create_window('rekam', 'https://g4lihru.me/meet/')
    webview.start(http_server=True)

kuliah.add_command(label="Rekam",image=RekamIcon,compound=tk.LEFT,accelerator="Alt+R",command=rekam)
kuliah.add_separator()

def cloud(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.geometry("800x600")
    webview.create_window('Cloud GALIH RIDHO UTOMO', 'https://g4lihriu.web.app/pdf.html')
    webview.start(http_server=True)

kuliah.add_command(label="Cloud", image=CloudIco, compound=tk.LEFT,accelerator="Ctrl+Alt-C",command=cloud)

def drive(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.geometry("800x600")
    CatatanKu.iconbitmap('icons/favicon.ico')
    webview.create_window('Drive GALIH RIDHO UTOMO', 'http://drive.google.com/')
    webview.start(http_server=True)

kuliah.add_command(label="Drive Google", image=DriveIcon, compound=tk.LEFT,accelerator="Ctrl+Alt-D",command=drive)
kuliah.add_separator()

def elena(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.geometry("800x600")
    webview.create_window('Catatan - Elena', 'https://apps.unnes.ac.id/gate/list')
    webview.start(http_server=True)

kuliah.add_command(label="Elena", image=ElenaIcon, compound=tk.LEFT,accelerator="Ctrl+Alt-E",command=elena)

def clsr(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.geometry("800x600")
    webview.create_window('Catatan - Classroom', 'https://classroom.google.com')
    webview.start(http_server=True)

kuliah.add_command(label="Classroom",image=ClassIcon, compound=tk.LEFT,accelerator="Ctrl+Alt-G",command=clsr)
kuliah.add_separator()

if platform.system() == "CatatanKudows":
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)
    userSaid = "hello world"
else:
    engine = pyttsx3.init()
    engine.setProperty('voice', 'english-us')
    engine.setProperty('rate', 160)
    userSaid = "hello world"

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def galbot(event=None):
    speak("Hello, I'm Galbot, nice to meet you. Galbot is running the program")
    os.system("python galbot.py Arg")

ai.add_command(label="GalBot",image=GalbotIcon,compound=tk.LEFT,accelerator="Alt+G",command=galbot) 

s=ttk.Style()
s.configure("TButton", foreground="red", background="blue")
TemaList = s.theme_names()
current_theme = s.theme_use()
#s.theme_use('classic')
print(TemaList)
'''
'''
def theme_random(event=None):
    # choose a theme randomly
    theme = random.choice(TemaList)
    color.entryconfigure(0, label=f'{theme} (Tema yang digunakan)')
    print("theme yang digunakan:", theme)
    s.theme_use(theme)

theme = random.choice(TemaList)

color.add_command(label=f"{theme}", image=RandomIcon,compound=tk.LEFT,accelerator="Random Ctrl+K", command= theme_random)
color.add_separator()

def vaii(event=None):
    CatatanKu.title('Catatanku')
    CatatanKu.iconbitmap('icons/vaii.ico')
    webview.create_window('VAII', 'https://g4lihru.me/ai/vaii/')
    webview.start()

ai.add_command(label="VAII",image=VAIIIcon,compound=tk.LEFT,accelerator="Alt+V",command=vaii)

def emai(event=None):
    CatatanKu.title('EMAI')
    CatatanKu.iconbitmap('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAuCAYAAAC4e0AJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGwWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNy4wLWMwMDAgNzkuMjE3YmNhNiwgMjAyMS8wNi8xNC0xODoyODoxMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIyLjQgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMS0xMS0wOFQxODowMTozMiswNzowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjEtMTEtMDhUMTg6MDk6NDErMDc6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjEtMTEtMDhUMTg6MDk6NDErMDc6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmE0ZmI2ZjFhLTY3NjYtM2Q0MC1iYzU1LWNmYjFkY2QzMjZkNCIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjVkYzMxMDNjLTZjNmUtZmU0Yy05NjVhLTVjYTFjNWU4OTI5NCIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmMxNzRmMWE1LTZjNGYtOGU0YS04MGQ3LWQxY2ZiYjdlMmFlMiI+IDxwaG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDxyZGY6QmFnPiA8cmRmOmxpPnhtcC5kaWQ6YWIwYTYzYmYtOWFjNC1jMDRmLTg2ZTEtZGUwNDIzMjFkZTVjPC9yZGY6bGk+IDwvcmRmOkJhZz4gPC9waG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YzE3NGYxYTUtNmM0Zi04ZTRhLTgwZDctZDFjZmJiN2UyYWUyIiBzdEV2dDp3aGVuPSIyMDIxLTExLTA4VDE4OjAxOjMyKzA3OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjIuNCAoV2luZG93cykiLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNvbnZlcnRlZCIgc3RFdnQ6cGFyYW1ldGVycz0iZnJvbSBhcHBsaWNhdGlvbi92bmQuYWRvYmUucGhvdG9zaG9wIHRvIGltYWdlL3BuZyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YTRmYjZmMWEtNjc2Ni0zZDQwLWJjNTUtY2ZiMWRjZDMyNmQ0IiBzdEV2dDp3aGVuPSIyMDIxLTExLTA4VDE4OjA5OjQxKzA3OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjIuNCAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+ws3IrAAAB8JJREFUaIGtmNuLXVcZwH/f2vucGWdOMpk0M+Nk0qltkkmwUkawPohFUEFfFOyT/RekSF+KKMYb+FIRkRBUhDw1D6IUH0RBrKBIREObtE0iSZMmk8wkk2ky95kz55y91+fDvl/OZUcXbNZea6+19+/79nfbW1SVv3ztjR99/vl/v2xcT1FAANGkJzVGs9cprOv4lr9a1X/t7Tl/7rRrN4dH9trGWBzXIsZiPYPvO7SaDvl24DunC3PdmgsgaAMYRyWcVoLzUBIJe1UQyV6XcD5ap4Lj6EsOvOQ2/KZV/67v8xtVTgMfDkw2QDNhL2jIqpAIIck435Mak5u3wbnARxzDXL2up+pDctFx5AzIx/6v8IrarsDxOLycFpJu5znhAkFmjDHfcB3nvBi+FG0xRjNHZXiD2szDopYBkywYJeO88PmxBZBpt2Zer9X1m2pha3WIrbXkqNICm1eVGE5SAghZeyZl33l7Jzdf5hdhL8ih2rD9uetycPX+yA8cx8ZAM1XhgweltBRDUQ7SbZwXUHo4tmfYd9D7/ideWL7T2TNno8dVaaHDqhvJkDGdvIPmTaKvA5PdV/AFwLpnmtvup5qbNZpbtUrwkead4IaSWMAgpiLhG1t/BLcuQseFjgNtJzhvh+OOU3JuwHOQjjM85pkL+A7ea3UpxyxvJsDUoUzE6BpxShzaKtz6ILhVpID4CIWzKU1n3oaESgmY2yVJqz+86F4AI/SNKvk1S/dgdy8rVGZvWnBJok4h9ApDw/5EFfjIbLzErkmcLB9FIGtWrRbcWQzWN11wgLoHw204eBCOP9ethCgtNWzbfs6B3w0KHznsaAzdzTnj65EEwI0F6NjQLEKNWgAHZubKzS6+F9n7Bv1nBgWP4SUKdenyoOS1ZoRa3YTlRwF4+lADU7MwPJLdn4YuRKfg3DHyYhX4yGxaMRikogvlEQfg2kKobQExgcbFQm0IDs8mUAMUctFi4/JUFfhA86qtYjQg9xZS2lpYgY1mYi4+ieZnnwHjJmt75oEeJjooPKib2HsqKpTVK20P3r8H1gSwfmgqKrD/ABya7APWJWHF8xXhBU0qojJbT9/8P0vQsqFzpsDVwDPHeoP1deDH0bxgM/G7W3m83oQ7jxLYWPsGpqdhdKQIVmZ2XR24EntsNlqoQ/IPtQLvLAZmEh2Rnbs1ePrJAWw6B9ztLVSBF9RksmHJxwS3H8HD3cRJ42wpcHQ2ECC9J4YkBdnH3h/HYQVbtPG01to+XH4QatokvS+wrwGHJ8s1G+3PXOtjVlXhgXZpPRPd+PID2PUTTUcCIPDxp8JtfTQbjfP3LxOoCryo9btGhPUWXFtLwOMyQODIBIw1ck7YB6wgUG5fhebGZ4VaI8yGF5YD80ACWcUGfV3gxAxJ9o2AcgVdr68rJCnQUkl90BZFG7LJKZy6vQn3d1PmEh3AyWmo17KaiwUPx/k6qaAkim+lQot+OjmF0sBXuPBhYiaR1q2BsWF4+lAKJqfpwvdtbk3Z2vgtDd5CzduhjOQqcOkRbHcS51QSrc/PBFu7hdVIqHjcLe53G1eAF8HPgG+24cp6AqupCHNkHCYaxJ9vXSHS11NC9qptKrZI8+3EPgX++RA6ENctUXQxDsx/tJh86DXOCdUtl+TNdlB4xWxlZk8cgNF6Ah2ZzbMTMFIvh8l8r6aF6BHrM9dTcwO2MFTKQnIThdkGzIzAe6tw+WEw33Dh5BPJg/IfGelfIWXO2ctJH9NsXABP3fdRFI0Cr4Jj4JNPwLH9Qaw/ORbMlQJH4xKhRLj09hKT7xqmNoZwwmW+KA8OtFiZ95h/fjrKFZUMxwWYm713XcRdQWWqoJl9NfjCkyFQN2CKGg/XXH/jLvOLo7DuE8ZcIPjRcHitzuH1Ya7fvM/c16dB7WIVeAMw1thZUeP9LZOkyhyvNNXno0Wy5tLFJeZi8C5tzTJ3t8GlC8tY375dGf6DO+Msr9de1yDGZB2vLDKQHmeB04JMvie9wVMCTL3j4lv/T5Xhx8eb1Eaaf1S1i2hUMURvITpKBCkr5FJrpjYG/98+uVr3Td3+tjL8xPgO42M7vtabPytkurL6I5OIKGg8GjsVMqazq2utHbtaGd63grUG3907rU77713L2IJQUrKGeOxXqFX8tm7tbgxgYnn4na1acGy7bLc7P0Hxetp6af1C8jbC8YOx9sAgC7p9q3HA9F+Yh796bZSr10a5fHUfNxedP9ihrZfTEKVpPV/GFnpYeRYYG+i39e1zeuNcbegx4I8f3eb40W3mjm0ze6SJ1nd/Zd2d1yAsDdICpOuQMvCUP8w/d4TrM81+Atw+rw/On/LeOqvVrCZIUpMTrXhCQ8DNzu63pC3b+4dHfoiKIDaVNSMheqV+QIS5r85y6d1FJq/A1EYdJxBe/aa/cru1eeWc3jz3Pe+ts9Www9urKv6pVzKTjgNLSy6bm8KJo3xW2o2fiq19GmMTeMn1mfkIPr8G1HgXrdt81dJ5EwGJa5tQm9/+xcDwXY1MBIyANZ1/dOobX/bd3R+DbgZbpOgHmTifz8ACyq6nzV9ubT78ohj/TZHqhVi+uf2XCIqu+bWd7/p279d49RddcV8wWvsKatykKky0GwsntqPYJTXt3/vSOmP99g2v7ZEqhv6n9l87C971JRziJQAAAABJRU5ErkJggg==')
    webview.create_window('EMAI', 'https://g4lihru.me/ai/emai/')
    webview.start()

ai.add_command(label="EMAI",image=EMAIIcon,compound=tk.LEFT,accelerator="Alt+E",command=emai)

def OpenFile(event=None):
    global url
    url = filedialog.askopenfilename(initialdir=os.getcwd(),title="Select File",filetypes=(("Text files","*.txt"),("Python file","*.py"), ("All files","*.*")))
    try:
        with open(url,'r') as fr:
            TextEditor.delete(1.0,tk.END)
            TextEditor.insert(1.0,fr.read())
    except FileNotFoundError:
        return
    except:
        return 
    CatatanKu.title(os.path.basename(f"{url} - Catatanku"))

file.add_command(label="Open", image=OpenIcon, compound=tk.LEFT, accelerator="Ctrl+O", command=OpenFile)
file.add_separator()

def about(event=None):
    showinfo('Tentang', '''Catatanku
    Aplikasi catatanku dibuat oleh Mahasiswa UNNES Galih Ridho Utomo.''')

tentang.add_command(label="About",image=AboutIcon,compound=tk.LEFT, accelerator="Home", command=about)

def help(event=None):
    showinfo('Pusat Bantuan', '''Short Cut Aplikasi Catatan\n
Perintah Catatan\n
Ctrl+N      FileBaru
Ctrl+O      OpenFile
Ctrl+S      Save
Ctrl+Shift+S  Save As
Ctrl+F      Find
Ctrl+K      Mengubah Tampilan ToolBar
Ctrl+Q      Quit\n
Style Penulisan\n
Ctrl+B      Bold
Ctrl+U      Underline
Ctrl+I      Italic
Ctrl+E      Center
Ctrl+L      Left
Ctrl+R      Right\n
Perintah AI\n
Alt+V       vaii
Alt+G       galbot
Alt+E       emai\n
Perintah Aktivitas Kuliah\n
Alt+R       Merekam Pertemuan Online
Alt+H       Mengubah Suara Jadi Tulisan
Ctrl+Alt+C  Membuka Cloud
Ctrl+Alt+D  Membuka Google Drive
Ctrl+Alt+E  Membuka Elena UNNES
Ctrl+Alt+G  Membuka Google Classroom
Alt+U       Menjalankan File Python
Home        About
Esc         Membuka Pusat Bantuan''')

tentang.add_command(label="Help",image=AboutIcon,compound=tk.LEFT, accelerator="Esc", command=help)

def speech(event=None):
    pyautogui.hotkey("win", "h")

kuliah.add_command(label="Speech Write",image=SpwrIcon,compound=tk.LEFT, accelerator="Alt+H", command=speech)

def run(event=None):
    if url == " ":
        showerror('Kesalahan', 'Harap menyimpan terlebih dahulu file !!')
    else:
        if '.py' in url:
            code = TextEditor.get('1.0', tk.END) 
            exec(code)
            #print(url)
            #TextEditor.insert('END', exec(code))
        else:
            showerror('Error', 'This is not a valid Python File !!')

kuliah.add_command(label="Run",image=RunIcon,compound=tk.LEFT, accelerator="Alt+U", command=run)

def PerintahSave(event=None):
    global url
    try:
        if url:
            content=str(TextEditor.get(1.0,tk.END))
            with open(url,'w',encoding='utf-8') as wf:
                wf.write(content)
        else:
            url=filedialog.asksaveasfile(mode='w',defaultextension=".txt",filetypes=(("Text files","*.txt"),("Python file","*.py"),("All files","*.*")))
            content=TextEditor.get(1.0,tk.END)    
            url.write(content)
            url.close()
    except:
        return

file.add_command(label="Save", image=SaveIcon, compound=tk.LEFT, accelerator="Ctrl+S", command=PerintahSave)

def SimpanKu(event=None):
    global url
    try:
        url = filedialog.asksaveasfile(mode='w', defaultextension=".txt", filetypes=(("Text files","*.txt"), ("Phyton files","*.py"), ("All files","*.*")))
        content = TextEditor.get(1.0,tk.END)
        url.write(content)
        url.close()
    except:
        return
    CatatanKu.title(os.path.basename(f"{url} - Catatanku"))

file.add_command(label="Save As", image=SaveAsIcon, compound=tk.LEFT, accelerator="Ctrl+Shift+S", command=SimpanKu)
file.add_separator()

def Print(event=None):
    if url == " ":
        showerror('Kesalahan', 'Harap menyimpan file terlebih dahulu sebelum di print !!')
    else:
        os.startfile(url, 'print')

file.add_command(label="Print", image=PrintIcon, compound=tk.LEFT, accelerator="Ctrl+P", command=Print)
file.add_separator()

def PerintahKeluar(event=None):
    global url,TextPeru
    try:
        if TextPeru:
            mbox = messagebox.askyesnocancel("Warning!","Do you want to save your file?")
            if mbox:
                if url:
                    content = str(TextEditor.get(1.0,tk.END))
                    with open(url,'w',encoding='utf-8') as wf:
                        wf.write(content)
                        CatatanKu.destroy()
                else:
                    url = filedialog.asksaveasfile(mode='w',defaultextension=".txt",filetypes=(("Text files","*.txt"),("Python file","*.py"), ("All files","*.*")))
                    content2 = TextEditor.get(1.0,tk.END)    
                    url.write(content2)
                    url.close()
                    CatatanKu.destroy()
            elif mbox is False:
                CatatanKu.destroy()
        else:
            CatatanKu.destroy()
    except:
        return

file.add_command(label="Exit", image=ExitIcon, compound=tk.LEFT, accelerator="Ctrl+Q", command=PerintahKeluar)

def PerintahCari(event=None):
    def find():
        word = FindInput.get()
        TextEditor.tag_remove("match", '1.0', tk.END)
        matches = 0
        if word:
            StarPos = '1.0'
            while True:
                StarPos = TextEditor.search(word, StarPos, stopindex=tk.END)
                if not StarPos:
                    break
                EndPos = f'{StarPos}+{len(word)}c'
                TextEditor.tag_add('match', StarPos, EndPos)
                matches += 1
                StarPos = EndPos
                TextEditor.tag_config('match', foreground='red', background='yellow')
            
    def replace():
        word=FindInput.get()
        replace_content=replace_input.get()
        content=TextEditor.get(1.0, tk.END)
        NewCon=content.replace(word, replace_content)
        TextEditor.delete(1.0, tk.END)
        TextEditor.insert(1.0, NewCon)

    FindDig=tk.Toplevel()
    FindDig.geometry('450x250+500+200')
    FindDig.title("Find")
    FindDig.resizable(0, 0)

    FindFrame=ttk.Labelframe(FindDig, text="Find/Replace")
    FindFrame.pack(pady=20)

    tfl=ttk.Label(FindFrame, text="Find: ")
    trl=ttk.Label(FindFrame, text="Replace")
    tfl.grid(row=0, column=0, padx=4, pady=4)
    trl.grid(row=1, column=0, padx=4, pady=4)

    FindInput=ttk.Entry(FindFrame, width=30)
    replace_input=ttk.Entry(FindFrame, width=30)
    FindInput.grid(row=0, column=1, padx=4, pady=4)
    replace_input.grid(row=1, column=1, padx=4, pady=4)
    FindButton=ttk.Button(FindFrame, text="Find", command=find)
    replace_button=ttk.Button(FindFrame, text="Replace", command=replace)
    FindButton.grid(row=2, column=0, padx=4, pady=4)
    replace_button.grid(row=2, column=1, padx=4, pady=4)


edit.add_command(label="Copy",image=CopyIcon,compound=tk.LEFT, accelerator="Ctrl+C", command=lambda:TextEditor.event_generate("<Control c>"))
edit.add_command(label="Paste",image=PasteIcon,compound=tk.LEFT, accelerator="Ctrl+V", command=lambda:TextEditor.event_generate("<Control v>"))
edit.add_command(label="Cut", image=CutIcon, compound=tk.LEFT, accelerator="Ctrl+X", command=lambda:TextEditor.event_generate("<Control x>"))
edit.add_separator()

edit.add_command(label="Find", image=FindIcon, compound=tk.LEFT, accelerator="Ctrl+F", command=PerintahCari)

TampilToolBar = tk.BooleanVar()
TampilToolBar.set(True)
TampilStatusBar = tk.BooleanVar()
TampilStatusBar.set(True)

def HideToolBar():
    global TampilToolBar
    if TampilToolBar:
        ToolBar.pack_forget()
        TampilToolBar = False
    else:
        TextEditor.pack_forget()
        StatusBar.pack_forget()
        ToolBar.pack(side=tk.TOP, fill=tk.X)
        TextEditor.pack(fill=tk.BOTH, expand=True)
        StatusBar.pack(side=tk.BOTTOM)
        TampilToolBar = True

def HideStatusBar():
    global TampilStatusBar
    if TampilStatusBar:
        StatusBar.pack_forget()
        TampilStatusBar = False
    else:
        StatusBar.pack(side=tk.BOTTOM)
        TampilStatusBar = True
 
view.add_checkbutton(label="Status Bar", onvalue=True, offvalue=False, variable=TampilStatusBar, image=StatusBarIcon, compound=tk.LEFT,command=HideStatusBar)
view.add_checkbutton(label="Tool bar", image=ToolBarIcon, onvalue=True, offvalue=False, variable=TampilToolBar, compound=tk.LEFT, command=HideToolBar)

def GantiTema():
    PilihanTema = ThemeChoise.get()
    ColTur = ColorList.get(PilihanTema)
    FColor, BColor = ColTur[0] ,ColTur[1]
    TextEditor.config(background=BColor, fg=FColor)

count = 0
for i in ColorList:
    color.add_radiobutton(label=i,image=ColorIcon[count],variable=ThemeChoise,compound=tk.LEFT,command=GantiTema)
    count += 1

CatatanKu.config(menu=MainMenu)

CatatanKu.bind('<Control-n>', FileBaru)
CatatanKu.bind('<Control-o>', OpenFile)
CatatanKu.bind('<Control-s>', PerintahSave)
CatatanKu.bind('<Control-Shift-S>', SimpanKu)
CatatanKu.bind('<Control-f>', PerintahCari)
CatatanKu.bind('<Control-q>', PerintahKeluar)
CatatanKu.bind('<Control-b>', NgubahBold)
CatatanKu.bind('<Control-u>', NguUnLin)
CatatanKu.bind('<Control-i>', NgubahItalic)
CatatanKu.bind('<Control-e>', center)
CatatanKu.bind('<Control-l>', left)
CatatanKu.bind('<Control-r>', right)
CatatanKu.bind('<Alt-v>', vaii)
CatatanKu.bind('<Alt-g>', galbot)
CatatanKu.bind('<Alt-e>', emai)
CatatanKu.bind('<Alt-r>', rekam)
CatatanKu.bind('<Alt-h>', speech)
CatatanKu.bind('<Control-Alt-c>', cloud)
CatatanKu.bind('<Control-Alt-d>', drive)
CatatanKu.bind('<Control-Alt-e>', elena)
CatatanKu.bind('<Control-Alt-g>', clsr)
CatatanKu.bind('<Alt-u>', run)
CatatanKu.bind('<Control-q>', quit)
CatatanKu.bind('<Home>', about)
CatatanKu.bind('<Escape>', help)
CatatanKu.bind('<Control-k>', theme_random)

CatatanKu.mainloop()