from distutils import extension
from fileinput import filename
import os
import shutil
import time
import pyttsx3
import speech_recognition as sr
import datetime
import platform
import easygui

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


if platform.system() == "Windows":
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)
    userSaid = "hello world"
else:
    engine = pyttsx3.init()
    engine.setProperty('voice', 'english-us')
    engine.setProperty('rate', 160)
    userSaid = "hello world"


# Wishing Function
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning! SPRIT!")

    elif hour >= 12 and hour < 18:
        speak("Good afternoon!")

    else:
        speak("Good night!")

def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def takecommand(wtr=0):
    r = sr.Recognizer()
    r.pause_threshold = 1
    r.operation_timeout = 5
    with sr.Microphone() as source:
        speak("Can I help you, Galih!")
        speak("Listening...!")
        print("Listening...")
        audio = r.listen(source, phrase_time_limit=5)

        try:
            print("Recognizing...\n")
            heard = r.recognize_google(audio)
            print(f"You Said: \"{heard}\"")
            return heard.lower()
        except sr.UnknownValueError:

            speak("Sorry I'm not hear you. Can you speak again!")
            print(
                "You said something that is beyond my understanding or maybe you didn't say anything.\n")
            engine.runAndWait()
            return 0

def introduction():
    print("Getting started without wasting your precious time...")
    msg = "Silakan masukan nama anda"
    title = "Perkenalan Galbot"
    fieldNames = ["Nama"]
    fieldValues = [] 
    fieldValues = easygui.multenterbox(msg,title, fieldNames)
    print(fieldValues)

    while 1:
        if fieldValues == None: break
        errmsg = ""
        for i in range(len(fieldNames)):
            if fieldValues[i].strip() == "":
                errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
        if errmsg == "": break # no problems found
        fieldValues = easygui.multenterbox(errmsg, title, fieldNames, fieldValues)
    speak(f"Hallo {fieldValues[0]}")

# ScilenceChecker Function Takes input and removes scilence
# def scilenceChecker():
# 	userSaid = takecommand().lower()
# 	if userSaid == "":
# 		userSaid = "nothing"
# 	elif userSaid == " ":
# 		userSaid = "nothing"
# 	else:
# 		userSaid = takecommand().lower()


def clearLog():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")


creditsScreen = '''
 _____ _                 _          _____            _   _     _
|_   _| |__   __ _ _ __ | | _____  |  ___|__  _ __  | | | |___(_)_ __   __ _
  | | | '_ \ / _` | '_ \| |/ / __| | |_ / _ \| '__| | | | / __| | '_ \ / _` |
  | | | | | | (_| | | | |   <\__ \ |  _| (_) | |    | |_| \__ \ | | | | (_| |
  |_| |_| |_|\__,_|_| |_|_|\_\___/ |_|  \___/|_|     \___/|___/_|_| |_|\__, |
                                                                       |___/

'''

clearLog()

welcomeSplashScreen = f'''
---------------------------------------------------------------------------	
 _ _ _ _ _ _ 
| |_ _ _ _ _|          / \ \	     | |	     OOO   | |         | |
| |                   /   \ \        | |             | |   | |         | |
| |_ _ _ _ _         /     \ \       | |             | |   | |_ _ __ __| |
| | _ _ _ _ |       / + + + \ \      | |             | |   | | _ _ _ _ | |
|         | |      /         \ \     | |             | |   | |         | |
| _ _ _ _ | |     /           \ \    | | __ __ _     | |   | |         | |
|_ _ _ _ _|_|    /             \ \   | _ _ _ _ _|    | |   | |         | |
---------------------------------------------------------------------------	            

list perintah

1. Note
2. Open browser
3. Clear log
4. Neat
5. Sample Program
6. Add program
7. Stop
'''
clearLog()
print(f"{bcolors.OKCYAN + welcomeSplashScreen + bcolors.ENDC}")

if __name__ == '__main__':
    introduction()
    wishMe()
    looper = 5

    while looper != 10:

        query = str(takecommand())

        # Probablity of Commands

        if "note" in query:
            command = "C:\\WINDOWS\\system32\\notepad.exe"
            os.system(command)
        elif "open browser" in query:
            command = "start https://www.google.com"
            os.system(command)
        elif "clear log" in query:
            clearLog()
        elif "new file" in query:
            speak(f"Please wait, I will make the file!")
            os.system("python beta.py Arg")
        elif "pause" in query:
            a = input("press any key to continue...")
        elif "neat" in query:
            speak("please enter the path you want to tidy up")
            path = input("Enter Path: ")
            files = os.listdir(path)
            for file in files:
                filename, extension = os.path.splitext(file)
                extension = extension[1:]

                if os.path.exists(path+ '/' + extension):
                    shutil.move(path+'/'+file, path+'/'+extension+'/'+file)
                else:
                    os.makedirs(path+'/'+extension)
                    shutil.move(path+'/'+file, path+'/'+extension+'/'+file)
            speak(f"It's been tidied up in this path, {path}")
        elif "1" in query:
            speak("Loading program... Opening program")
            os.system("python airf.py Arg")
        elif "program" in query:
            speak("Please write the program you want to add!")
            msg = "Silakan masukan nama perintah"
            title = "Menambahkan progam"
            fieldNames = ["Nama Perintah"]
            fieldValues = [] 
            fieldValues = easygui.multenterbox(msg,title, fieldNames)
            print(fieldValues)

            while 1:
                if fieldValues == None: break
                errmsg = ""
                for i in range(len(fieldNames)):
                    if fieldValues[i].strip() == "":
                        errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
                if errmsg == "": break # no problems found
                fieldValues = easygui.multenterbox(errmsg, title, fieldNames, fieldValues)
            speak(f"command has been added successfully {fieldValues[0]}")
            if f"{fieldValues[0]}":
                print('''
                Progam ini termasuk ke dalam
                1. meet
                2. progam python lain
                3. membuka browser dengan alamat tertentu
                ''')
                adcom = input("Masukan angka pilihan: ")
                if adcom == "3":
                    alamat = input("Masukan alamat website: ")
                    speak(f"command has been added successfully {alamat}")
                    speak(f"please try the program that has been added with the command {fieldValues[0]}")
                else:
                    print("sorry!")

        elif f"{fieldValues}":
            speak(f"Open the browser for the website address {fieldValues[0]}")
            command = f"start {alamat}"
            os.system(command)

        elif "stop" in query:
            speak("ending program, thanks for using GalBot")
            os.system("cls")
            print(f"{bcolors.OKCYAN + creditsScreen + bcolors.ENDC}")
            print("GalBot ended sucessfully")
            looper = 10

        else:
            print("\n\nREQUEST ERROR\n\n")
